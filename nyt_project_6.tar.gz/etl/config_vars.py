# Your New York Times API key
NYT_API_KEY="pd1P76og3dcjPtr0p5aj3ER0sqVpcdPy"

INPUT_DATA_DIR="input_data"
OUTPUT_DATA_DIR="output_data"

# Years to extract from
# from start to end year
START_YEAR=2021
END_YEAR=2022

# Months of the year to extract from
# from start month to end month
START_MONTH=1
END_MONTH=1

# MongoDB
MONGODB_URL='mongodb://root:1234@172.25.0.9:27017/'
MONGODB_NYT_DB_NAME='nyt_db_mongo'
MONGODB_NYT_COL_NAME='nyt_articles_collection'
JSON_TO_CSV_FILE_NAME='extracted_data.csv'

# SQLite
SQLITE_NYT_DB_NAME='nyt_db.db'
SQLite_NYT_DB_DIR="output_data"
CLEAN_CSV_FILE_NAME='extracted_data_clean.csv'
