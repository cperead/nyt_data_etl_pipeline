# COMMANDS I USE: (for standalone container)

# ================= 0. ================= #
# Tar compress
tar -czvf /mnt/c/Users/carlo/gdrive/perea_stix/A__OurDocs__PS/7__Privado_Carlos/Data_Engineer/DE_Project_NY_News/only_cp/nyt_project_5.tar.gz .

# Tar uncompress (in this case for test)
mkdir test_to_delete 
tar -xzvf /mnt/c/Users/carlo/gdrive/perea_stix/A__OurDocs__PS/7__Privado_Carlos/Data_Engineer/DE_Project_NY_News/only_cp/nyt_project_5.tar.gz \
    -C ~/nyt_project/test_to_delete/

# Copy
cp /mnt/c//Users/carlo/gdrive/perea_stix/A__OurDocs__PS/7__Privado_Carlos/Data_Engineer/DE_Project_NY_News/DB\ Diagram/data_cleaning_and_normalization.png ./images/

# ================= 1. ================= #
# docker-compose down                      # Stop compose
# docker kill $(docker ps -q)              # kill all running containers
# docker rm -f $(docker ps -a -q)          # remove all containers
# docker rmi $(docker images -q)           # remove all images
# docker volume rm $(docker volume ls -q)  # remove all volumes
# docker system prune --volumes            # clean all system

docker-compose down; \
docker kill $(docker ps -q); \
docker rm -f $(docker ps -a -q); \
docker rmi $(docker images -q); \
docker volume rm $(docker volume ls -q); \
docker system prune --volumes

rm -r output_data/* input_data/*

# Delete image without specifying ID (can be reworked to whichever container by changing the grep arg)
# docker image rm -f $(docker image ls | grep mongo | awk '{print $3}') &&
# docker rm -f $(docker ps -a | grep mongo | awk '{print $1}')

grep -roh '{"abstract":' . | wc -w 

# ================= 2. ================= #
# Test the docker-compose.yml
docker compose up

# ================= 3. ================= #

http://127.0.0.1:8000/


# ================= 4. ================= #

# If test individually
docker network create --subnet=172.25.0.0/16 service-net


A:
# RAN FROM THE Project CONTEXT
docker build -f A.extract.Dockerfile -t extract_app/ubuntu:1.0 .

# Start the container
#docker run --rm -v /srv/docker_playground/docker-expert/Project/input_data:/input_data extract_app/ubuntu:1.0
docker run --rm -v $(pwd)/input_data:/input_data extract_app/ubuntu:1.0


B:
# Config MongoDB in ./etl/config_vars.py
MONGODB_URL='mongodb://root:1234@172.25.0.9:27017/'

# RAN FROM THE Project CONTEXT
docker build -f B.convert.Dockerfile -t convert_data_app/mongo:1.0 .

# Create a docker network
docker network create --subnet=172.25.0.0/16 service-net

# Run MongoDB with a static IP
docker run -d \
--net service-net \
--ip 172.25.0.9 \
-e MONGO_INITDB_ROOT_USERNAME=root \
-e MONGO_INITDB_ROOT_PASSWORD=1234 \
-p 27017:27017 \
convert_data_app/mongo:1.0

# Run the script
docker run --rm \
--net service-net \
--ip 172.25.0.15 \
-v $(pwd)/input_data:/input_data \
-v $(pwd)/output_data:/output_data \
--name convert_data_mongo \
convert_data_app/mongo:1.0 \
python3 /etl/convert_data.py


C:
# RAN FROM THE Project CONTEXT
docker build -f C.db-create.Dockerfile -t create_db_app/ubuntu:1.0 ${PWD}

# Start the container
docker run --rm -v ${PWD}/output_data:/output_data create_db_app/ubuntu:1.0


D:
# RAN FROM THE Project CONTEXT
docker build -f D.api.Dockerfile -t api/ubuntu:1.0 ${PWD}

# Start the container
docker run --rm \
--net service-net \
--ip 172.25.0.20 \
-p 8000:8000 \
-v $(pwd)/output_data:/output_data \
--name nty_api_db \
api/ubuntu:1.0 \
uvicorn main:app --host 0.0.0.0

# http://127.0.0.1:8000/docs

# To interrupt CTRL + C


# The docker compose file is ran either by docker compose, 
# which is going to build all the containers and run them in order. 
# One can also run them with docker compose --profile [SERVICE PROFILE] to run the services one by one or in different order.

docker compose -d up -> starts the docker compose services in detached mode